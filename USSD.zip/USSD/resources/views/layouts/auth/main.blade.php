@include('layouts.auth.header')
@yield('body')
@include('layouts.auth.footer')