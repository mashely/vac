@include('layouts.header')
@yield('body')
@include('layouts.footer')