<?php $__env->startSection('body'); ?>

<div class="auth-form-light text-left p-5">
  
    <h4>Do u want to register!.</h4>
    <h6 class="font-weight-light">Get start now.</h6>


                        <form method="POST"  class="pt-3" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                         
                            
                          <div class="form-group">

                            <input   placeholder="Email Address" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                          
                          <div class="form-group">
                            <input  placeholder="password" id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                        
                        
                        </div>

                        



                          <div class="mb-4">
                            <div class="form-check">

                                




                              <label class="form-check-label text-muted"  for="remember">
                                <input type="checkbox" class="form-check-input">
                                Remember me
                              <i class="input-helper"></i>
                            </label>
                            </div>
                          </div>
                          <div class="mt-3">
                            <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" >SIGN IN</button>
                          </div>
                          <div class="text-center mt-4 font-weight-light">
                            Dont have an account! <a href="<?php echo e(url('register')); ?>" class="text-primary">Register now</a>
                          </div>
                        </form>
               
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.auth.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\USSD_2\resources\views/auth/login.blade.php ENDPATH**/ ?>