
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(url('vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(url('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(url('js/misc.js')); ?>"></script>
  <script src="<?php echo e(url('js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('js/todolist.js')); ?>"></script>
  <!-- endinject -->
</body>


<!-- Mirrored from www.urbanui.com/melody/template/pages/samples/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:53 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\codefoundas\participate\mashely\USSD\resources\views/layouts/auth/footer.blade.php ENDPATH**/ ?>