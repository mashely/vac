

        </div>
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2018 <a href="https://www.urbanui.com/" target="_blank">Urbanui</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="far fa-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
    </div>
  </div>


  
  <!-- plugins:js -->
  <script src="<?php echo e(url('vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(url('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(url('js/misc.js')); ?>"></script>
  <script src="<?php echo e(url('js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('js/todolist.js')); ?>"></script>


  <script src="<?php echo e(url('js/c3.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('script'); ?>

  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>


<!-- Mirrored from www.urbanui.com/melody/template/pages/icons/font-awesome.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Sep 2018 06:08:48 GMT -->
</html>
<?php /**PATH C:\xampp\htdocs\USSD_2\resources\views/layouts/footer.blade.php ENDPATH**/ ?>